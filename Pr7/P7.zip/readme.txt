 

Directory for project 7. 
Executable files should be in 'bin' directory.
