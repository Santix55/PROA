#include "tabla.h"
#include "tabla_t.h"
#include <iostream>
using namespace std;

const int N_ELEMENTOS = 20;
const string SEPARATOR = "\n----------------------------\n";

int main () {
    cout << "1.- PREVIO" << endl;
    Tabla t (N_ELEMENTOS);

    for (int i=0; i<N_ELEMENTOS-1; ++i) {
        Alumno a(4);
        t.insertar(a.getDNI(), a);
    }
    Alumno a1(1);
    string dni = a1.getDNI();
    t.insertar(dni, a1);

    Alumno _;
    if (t.buscar(dni, _)) {
        cout << "El estudiante ha sido encontrado" << endl;
    }

    if (!t.buscar(""s, _)) {
        cout << "El estudiante no existe" <<endl;
    }

    cout << SEPARATOR; ////////////////////////////////////////


    cout << "2.- PREVIO" << endl;
    Tabla_t<string,Alumno> tt (N_ELEMENTOS);

    for (int i=0; i<N_ELEMENTOS; ++i) {
        Alumno a(4);
        tt.insertar(a.getDNI(), a);
    }

    if (!tt.buscar("Javier"s, _)) {
        cout << "El estudiante ha sido encontrado" <<endl;
    }

    if (!tt.buscar(""s, _)) {
        cout << "El estudiante no existe" <<endl;
    }
    cout << endl;



    return 0;
}
