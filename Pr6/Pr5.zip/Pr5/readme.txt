
Directory for project 5. 
Executable files should be in 'bin' directory.
 
